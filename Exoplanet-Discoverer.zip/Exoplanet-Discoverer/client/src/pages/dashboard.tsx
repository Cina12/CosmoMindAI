import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { motion, AnimatePresence } from "framer-motion";
import { Radar, Database, RefreshCw, Cpu, Activity } from "lucide-react";

import { useScans, useCreateScan } from "@/hooks/use-scans";
import { insertScanSchema } from "@shared/schema";
import { Header } from "@/components/layout/header";
import { CyberButton } from "@/components/ui/cyber-button";
import { CyberInput } from "@/components/ui/cyber-input";
import { ScanCard } from "@/components/ui/scan-card";
import { useToast } from "@/hooks/use-toast";

// Create a client-side validation schema
// We only ask for mass and distance. Backend logic calculates planetType and lifeChance.
// But wait! The prompt code shows the user entering mass and distance, 
// AND the backend schema implies we just save the result.
// Let's stick to the prompt's Python logic but implement it on the backend? 
// Or implementing the logic on the frontend and sending full object?
// The prompt had logic:
// if 0.1<= mass<=1: planet_type = "Остероид" ...
// if 0.8<= distance<=1 and planet_type == "Земного типа": life = "шанс жизни высок"
// 
// The backend schema `insertScanSchema` only picks `mass` and `distance`.
// This implies the calculation happens on the backend.
// HOWEVER, looking at the provided schema in the prompt:
// export const insertScanSchema = createInsertSchema(scans).pick({ mass: true, distance: true });
// This CONFIRMS we only send mass and distance.
// The backend MUST calculate planetType and lifeChance before inserting.
// Wait, I am the one generating frontend. I don't control backend logic in this turn.
// The instructions said "You are a frontend code generator".
// But the `insertScanSchema` in the prompt description only allows mass/distance.
// So I will send mass/distance. 
// IF the backend is already implemented (implied by "existing_frontend_files" context but actually I am writing code for a fullstack app in parallel?),
// actually the system prompt says "You are starting the development of a fullstack application... we develop the frontend and the backend in parallel."
// But in this specific turn I am ONLY generating frontend. 
// I must assume the backend route handler will perform the logic based on the input.

const formSchema = z.object({
  mass: z.coerce.number().min(0.0001, "Масса должна быть больше 0"),
  distance: z.coerce.number().min(0.0001, "Расстояние должно быть больше 0"),
});

type FormData = z.infer<typeof formSchema>;

export default function Dashboard() {
  const { toast } = useToast();
  const { data: scans, isLoading: isLoadingScans } = useScans();
  const createScan = useCreateScan();
  const [analyzing, setAnalyzing] = useState(false);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(formSchema),
  });

  const onSubmit = async (data: FormData) => {
    setAnalyzing(true);
    // Fake analysis delay for effect
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    createScan.mutate(data as any, { // Type assertion needed because schema expects only mass/distance but backend fills the rest? No, input schema IS mass/distance.
      onSuccess: () => {
        toast({
          title: "АНАЛИЗ ЗАВЕРШЕН",
          description: "Данные успешно обработаны системой.",
          className: "bg-primary/10 border-primary text-primary font-mono",
        });
        reset();
        setAnalyzing(false);
      },
      onError: (error) => {
        toast({
          title: "ОШИБКА СИСТЕМЫ",
          description: error.message,
          variant: "destructive",
          className: "font-mono",
        });
        setAnalyzing(false);
      },
    });
  };

  return (
    <div className="min-h-screen bg-background text-foreground flex flex-col font-sans selection:bg-primary/30">
      <Header />

      <main className="flex-1 container mx-auto px-4 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Panel: Analysis Form */}
        <div className="lg:col-span-4 xl:col-span-3 space-y-6">
          <section className="relative p-6 rounded-lg border border-primary/20 bg-card/40 backdrop-blur-sm overflow-hidden">
             {/* Decorative background elements */}
             <div className="absolute -right-10 -top-10 w-40 h-40 bg-primary/5 rounded-full blur-3xl" />
             <div className="absolute -left-10 -bottom-10 w-40 h-40 bg-secondary/5 rounded-full blur-3xl" />
             
             <div className="flex items-center gap-3 mb-6 pb-4 border-b border-white/10">
               <Cpu className="w-6 h-6 text-primary" />
               <h2 className="text-xl font-display text-white">ПАНЕЛЬ ВВОДА</h2>
             </div>

             <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
               <div className="space-y-2">
                 <label className="text-xs uppercase font-mono tracking-wider text-muted-foreground flex justify-between">
                   <span>Масса планеты</span>
                   <span className="text-primary/70">M⊕</span>
                 </label>
                 <CyberInput 
                   type="number" 
                   step="0.01" 
                   placeholder="1.0"
                   autoComplete="off"
                   {...register("mass")}
                 />
                 {errors.mass && (
                   <span className="text-xs text-red-400 font-mono">{errors.mass.message}</span>
                 )}
               </div>

               <div className="space-y-2">
                 <label className="text-xs uppercase font-mono tracking-wider text-muted-foreground flex justify-between">
                   <span>Расстояние до звезды</span>
                   <span className="text-primary/70">AU</span>
                 </label>
                 <CyberInput 
                   type="number" 
                   step="0.01" 
                   placeholder="1.0"
                   autoComplete="off"
                   {...register("distance")}
                 />
                 {errors.distance && (
                   <span className="text-xs text-red-400 font-mono">{errors.distance.message}</span>
                 )}
               </div>

               <div className="pt-4">
                 <CyberButton 
                   type="submit" 
                   className="w-full"
                   disabled={analyzing || createScan.isPending}
                 >
                   {analyzing ? (
                     <div className="flex items-center gap-2">
                       <RefreshCw className="w-4 h-4 animate-spin" />
                       ОБРАБОТКА...
                     </div>
                   ) : (
                     <div className="flex items-center gap-2">
                       <Radar className="w-4 h-4" />
                       АНАЛИЗИРОВАТЬ
                     </div>
                   )}
                 </CyberButton>
               </div>
             </form>
             
             {/* System Status Mockup */}
             <div className="mt-8 pt-6 border-t border-white/10 space-y-4">
               <div className="text-xs font-mono text-muted-foreground mb-2">СТАТУС СИСТЕМЫ</div>
               <div className="grid grid-cols-2 gap-2">
                 <div className="bg-black/40 p-2 rounded border border-white/5">
                   <div className="text-[10px] text-muted-foreground mb-1">CPU LOAD</div>
                   <div className="text-primary font-mono text-sm">12%</div>
                   <div className="w-full h-1 bg-white/10 mt-1 rounded-full overflow-hidden">
                     <div className="h-full w-[12%] bg-primary" />
                   </div>
                 </div>
                 <div className="bg-black/40 p-2 rounded border border-white/5">
                   <div className="text-[10px] text-muted-foreground mb-1">MEMORY</div>
                   <div className="text-secondary font-mono text-sm">45%</div>
                   <div className="w-full h-1 bg-white/10 mt-1 rounded-full overflow-hidden">
                     <div className="h-full w-[45%] bg-secondary" />
                   </div>
                 </div>
               </div>
             </div>
          </section>
        </div>

        {/* Right Panel: Results History */}
        <div className="lg:col-span-8 xl:col-span-9 space-y-6">
          <section className="h-full flex flex-col">
             <div className="flex items-center justify-between mb-6">
               <div className="flex items-center gap-3">
                 <Database className="w-6 h-6 text-secondary" />
                 <h2 className="text-xl font-display text-white">ЖУРНАЛ СКАНИРОВАНИЯ</h2>
               </div>
               <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground bg-white/5 px-3 py-1 rounded-full">
                 <Activity className="w-3 h-3 text-green-500" />
                 <span>ВСЕГО ЗАПИСЕЙ: {scans?.length || 0}</span>
               </div>
             </div>

             <div className="flex-1 min-h-[400px] rounded-lg border border-primary/10 bg-black/20 backdrop-blur-sm p-4 relative overflow-hidden">
                {/* Grid background effect */}
                <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none" />
                
                {isLoadingScans ? (
                  <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-4">
                    <div className="relative w-16 h-16">
                      <div className="absolute inset-0 border-t-2 border-primary rounded-full animate-spin"></div>
                      <div className="absolute inset-2 border-r-2 border-secondary rounded-full animate-spin-reverse"></div>
                    </div>
                    <p className="font-mono animate-pulse">ЗАГРУЗКА ДАННЫХ...</p>
                  </div>
                ) : !scans || scans.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-muted-foreground gap-4">
                    <div className="w-20 h-20 rounded-full bg-white/5 flex items-center justify-center border border-white/10">
                      <Radar className="w-10 h-10 opacity-50" />
                    </div>
                    <p className="font-mono text-sm max-w-xs text-center">Нет данных. Запустите сканирование для обнаружения экзопланет.</p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 relative z-10 overflow-y-auto max-h-[800px] pr-2 pb-20 custom-scrollbar">
                    <AnimatePresence mode="popLayout">
                      {/* We reverse the array to show newest first */}
                      {[...scans].reverse().map((scan, index) => (
                        <ScanCard key={scan.id} scan={scan} index={index} />
                      ))}
                    </AnimatePresence>
                  </div>
                )}
             </div>
          </section>
        </div>
      </main>
    </div>
  );
}
