import * as React from "react"
import { cn } from "@/lib/utils"

export interface InputProps
  extends React.InputHTMLAttributes<HTMLInputElement> {}

const CyberInput = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, ...props }, ref) => {
    return (
      <div className="relative group">
        <div className="absolute -inset-0.5 bg-gradient-to-r from-primary/30 to-secondary/30 rounded-sm blur opacity-25 group-hover:opacity-75 transition duration-500"></div>
        <input
          type={type}
          className={cn(
            "relative flex h-12 w-full rounded-sm border border-primary/20 bg-black/50 px-3 py-2 text-lg font-mono text-primary placeholder:text-primary/30 focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-primary focus-visible:border-primary transition-all duration-300",
            className
          )}
          ref={ref}
          {...props}
        />
        <div className="absolute bottom-0 right-0 w-2 h-2 border-r border-b border-primary/50"></div>
        <div className="absolute top-0 left-0 w-2 h-2 border-l border-t border-primary/50"></div>
      </div>
    )
  }
)
CyberInput.displayName = "CyberInput"

export { CyberInput }
