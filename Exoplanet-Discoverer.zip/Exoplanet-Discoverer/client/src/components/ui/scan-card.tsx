import { motion } from "framer-motion";
import { Activity, Disc, Globe, AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Scan } from "@shared/schema";

interface ScanCardProps {
  scan: Scan;
  index: number;
}

export function ScanCard({ scan, index }: ScanCardProps) {
  // Determine icon and color based on planet type
  let Icon = Globe;
  let colorClass = "text-blue-400";
  let borderClass = "border-blue-500/30";
  let glowClass = "shadow-blue-500/20";

  if (scan.planetType === "Остероид") {
    Icon = Disc;
    colorClass = "text-slate-400";
    borderClass = "border-slate-500/30";
    glowClass = "shadow-slate-500/20";
  } else if (scan.planetType === "Земного типа") {
    Icon = Globe;
    colorClass = "text-green-400";
    borderClass = "border-green-500/30";
    glowClass = "shadow-green-500/20";
  } else if (scan.planetType === "Супер-Земля") {
    Icon = Globe;
    colorClass = "text-cyan-400";
    borderClass = "border-cyan-500/30";
    glowClass = "shadow-cyan-500/20";
  } else if (scan.planetType === "Газовый гигант") {
    Icon = Activity;
    colorClass = "text-orange-400";
    borderClass = "border-orange-500/30";
    glowClass = "shadow-orange-500/20";
  } else {
    Icon = AlertTriangle;
    colorClass = "text-red-400";
    borderClass = "border-red-500/30";
    glowClass = "shadow-red-500/20";
  }

  return (
    <motion.div
      initial={{ opacity: 0, x: 20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: index * 0.05, duration: 0.3 }}
      className={cn(
        "relative p-4 rounded-sm border bg-card/50 backdrop-blur-sm overflow-hidden group hover:bg-card/80 transition-colors",
        borderClass,
        "shadow-lg",
        glowClass
      )}
    >
      <div className="absolute top-0 right-0 p-1 opacity-20 group-hover:opacity-40 transition-opacity">
        <Icon className={cn("w-16 h-16", colorClass)} />
      </div>

      <div className="relative z-10 grid grid-cols-2 gap-4">
        <div>
          <div className="text-xs text-muted-foreground uppercase font-mono tracking-wider mb-1">Тип объекта</div>
          <div className={cn("text-lg font-bold font-display uppercase truncate", colorClass)}>
            {scan.planetType}
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs text-muted-foreground uppercase font-mono tracking-wider mb-1">Дата сканирования</div>
          <div className="text-sm font-mono text-white/80">
            {new Date(scan.createdAt!).toLocaleDateString('ru-RU')}
          </div>
        </div>
        
        <div className="col-span-2 grid grid-cols-2 gap-4 py-2 border-t border-white/5">
           <div>
              <span className="text-xs text-muted-foreground mr-2 font-mono">МАССА:</span>
              <span className="text-primary font-mono">{scan.mass} M⊕</span>
           </div>
           <div className="text-right">
              <span className="text-xs text-muted-foreground mr-2 font-mono">РАССТОЯНИЕ:</span>
              <span className="text-primary font-mono">{scan.distance} AU</span>
           </div>
        </div>

        <div className="col-span-2 mt-1">
          <div className="text-xs text-muted-foreground uppercase font-mono tracking-wider mb-1">ВЫВОД СИСТЕМЫ</div>
          <div className="text-sm text-white/90 bg-white/5 p-2 rounded border-l-2 border-primary/50 font-mono">
            {scan.lifeChance}
          </div>
        </div>
      </div>
    </motion.div>
  );
}
