import * as React from "react"
import { cn } from "@/lib/utils"

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "destructive"
  size?: "sm" | "md" | "lg"
}

const CyberButton = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "md", children, ...props }, ref) => {
    const variants = {
      primary: "bg-primary/10 hover:bg-primary/20 text-primary border-primary/50 hover:shadow-[0_0_20px_rgba(34,211,238,0.4)]",
      secondary: "bg-secondary/10 hover:bg-secondary/20 text-secondary border-secondary/50 hover:shadow-[0_0_20px_rgba(168,85,247,0.4)]",
      destructive: "bg-destructive/10 hover:bg-destructive/20 text-destructive border-destructive/50 hover:shadow-[0_0_20px_rgba(239,68,68,0.4)]",
    }

    const sizes = {
      sm: "h-8 px-4 text-xs",
      md: "h-12 px-8 text-base",
      lg: "h-14 px-10 text-lg",
    }

    return (
      <button
        ref={ref}
        className={cn(
          "relative group overflow-hidden border font-display tracking-widest uppercase transition-all duration-300 focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed clip-corners",
          variants[variant],
          sizes[size],
          className
        )}
        {...props}
      >
        <div className="absolute inset-0 w-full h-full bg-gradient-to-r from-transparent via-white/5 to-transparent -translate-x-full group-hover:animate-shimmer" />
        <span className="relative z-10 flex items-center justify-center gap-2">
          {children}
        </span>
        
        {/* Decorative corner accents */}
        <div className="absolute top-0 left-0 w-1 h-1 bg-current opacity-50" />
        <div className="absolute bottom-0 right-0 w-1 h-1 bg-current opacity-50" />
      </button>
    )
  }
)
CyberButton.displayName = "CyberButton"

export { CyberButton }
