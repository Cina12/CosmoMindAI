import { Atom, Radio } from "lucide-react";

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-primary/20 bg-background/95 backdrop-blur-md">
      <div className="container mx-auto px-4 h-20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 flex items-center justify-center bg-primary/10 rounded-full border border-primary/50 shadow-[0_0_15px_-3px_var(--primary)] animate-pulse-slow">
            <Atom className="w-6 h-6 text-primary animate-spin-slow" />
          </div>
          <div className="flex flex-col">
            <h1 className="text-xl md:text-2xl font-display text-white tracking-widest uppercase">
              EXO<span className="text-primary">SCAN</span>
            </h1>
            <span className="text-[0.6rem] text-primary/70 font-mono tracking-[0.3em] uppercase">
              Система обнаружения
            </span>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-6">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/30">
             <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
             <span className="text-xs text-red-400 font-mono uppercase">Live Link</span>
          </div>
          <div className="flex items-center gap-2 text-primary/70">
            <Radio className="w-4 h-4" />
            <span className="text-xs font-mono">СИГНАЛ СТАБИЛЕН</span>
          </div>
        </div>
      </div>
      
      {/* Decorative scan line */}
      <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gradient-to-r from-transparent via-primary/50 to-transparent opacity-50"></div>
    </header>
  );
}
