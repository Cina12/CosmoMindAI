import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.get(api.scans.list.path, async (req, res) => {
    const scans = await storage.getScans();
    res.json(scans);
  });

  app.post(api.scans.create.path, async (req, res) => {
    try {
      const input = api.scans.create.input.parse(req.body);
      const { mass, distance } = input;

      // Business Logic Calculation
      let planetType = "Неизвестно";
      
      // Logic from user provided python code
      if (mass >= 0.1 && mass <= 1) {
        planetType = "Астероид"; // Corrected "Остероид" to "Астероид"
      } else if (mass > 1 && mass <= 2) { // 1.1 to 2 covered here roughly (float comparison)
        planetType = "Земного типа";
      } else if (mass < 10 && mass > 2) {
        planetType = "Супер-Земля";
      } else if (mass < 50 && mass >= 10) {
        planetType = "Газовый гигант";
      } else if (mass >= 50) {
        planetType = "Сверхгигант"; // Corrected "Сврехгигант"
      } else if (mass < 0.1) {
        planetType = "Карликовая планета/Астероид";
      }

      let life = "Жизнь маловероятна";
      
      if (distance >= 0.8 && distance <= 1 && planetType === "Земного типа") {
        life = "Шанс жизни высок";
      } else if (distance >= 1.6 && distance <= 2.4) {
        life = "Возможна жизнь (нужны исследования)";
      }

      const scan = await storage.createScan({
        ...input,
        planetType,
        lifeChance: life
      });
      
      res.status(201).json(scan);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      throw err;
    }
  });

  seedDatabase();
  return httpServer;
}

async function seedDatabase() {
  const existing = await storage.getScans();
  if (existing.length === 0) {
    console.log("Seeding database with initial scans...");
    await storage.createScan({
      mass: 1,
      distance: 1,
      planetType: "Астероид", // Based on logic 0.1<=mass<=1
      lifeChance: "Жизнь маловероятна" // Type is Asteroid, not Earth-like, so unlikely
    });
    // Note: Python logic says 0.1<=mass<=1 is Asteroid. 
    // Wait, Earth is mass 1. Usually Earth is Terrestrial. 
    // The user's python code says: 0.1 <= mass <= 1 -> "Остероид".
    // 1.1 <= mass <= 2 -> "Земного типа".
    // So mass 1 is Asteroid in their logic. I will stick to their logic strictly but correct spelling.
    
    await storage.createScan({
      mass: 1.5,
      distance: 1,
      planetType: "Земного типа",
      lifeChance: "Шанс жизни высок"
    });
    
    await storage.createScan({
      mass: 12,
      distance: 5.2,
      planetType: "Газовый гигант",
      lifeChance: "Жизнь маловероятна"
    });
  }
}

// Call seed after a short delay or allow main entry to call it? 
// In this setup, we can't easily export seedDatabase to index.ts without changing index.ts.
// We'll just run it once when this file is loaded/routes registered if we wanted, 
// but sticking to the plan: execute `seed` via tool or just let user create data.
// I will adhere to the "Seed database with realistic data" instruction by adding a self-invoking function or checking in registerRoutes.
// Better: Add it to registerRoutes to run on startup.

const originalRegisterRoutes = registerRoutes;
// We will just leave it. The instructions say "In server/routes.ts or a separate seed script, add initial data".
// I'll append the seed call inside registerRoutes.
