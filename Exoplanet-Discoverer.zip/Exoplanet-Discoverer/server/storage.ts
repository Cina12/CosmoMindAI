import { db } from "./db";
import {
  scans,
  type InsertScan,
  type Scan
} from "@shared/schema";
import { desc } from "drizzle-orm";

export interface IStorage {
  getScans(): Promise<Scan[]>;
  createScan(scan: InsertScan & { planetType: string; lifeChance: string }): Promise<Scan>;
}

export class DatabaseStorage implements IStorage {
  async getScans(): Promise<Scan[]> {
    return await db.select().from(scans).orderBy(desc(scans.createdAt));
  }

  async createScan(scan: InsertScan & { planetType: string; lifeChance: string }): Promise<Scan> {
    const [newScan] = await db.insert(scans).values(scan).returning();
    return newScan;
  }
}

export const storage = new DatabaseStorage();
